

axios.get('nbg.json')
    .then(response =>{
        console.log('axios response ', response);
}).catch(err){
    console.log(err);
}

formSubmit();