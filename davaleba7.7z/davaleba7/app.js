
// async function easy(){
//     try{
//         const result = await axios.get('https://fakerapi.it/api/v1/books?_quantity=5')
//         console.log(result);
//         return result;
//     }catch(err){
//         console.log(err);
//     }
// }

// easy();

axios.get('https://fakerapi.it/api/v1/books?_quantity=5')
    .then(response =>{
        console.log('axios response ', response);
    }).catch(err =>{
        console.log(err);
    })