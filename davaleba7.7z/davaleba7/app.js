
async function nbg(){
    try{
        const result = await axios.get('https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/ka/json')
        console.log(result);
        return result;
    }catch(err){
        console.log(err);
    }
}



nbg();

async function faker(){
    try{
        
        const result = await axios.get('https://fakerapi.it/api/v1/products?_quantity=1&_taxes=12&_categories_type=uuid')
        console.log(result);
        return result;
    }catch(err){
        console.log(err);
    }
}



faker();



// axios.get('https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/ka/json')
//     .then(response =>{
//         console.log('axios response ', response);
//     }).catch(err =>{
//         console.log(err);
//     })


    btn1.addEventListener('click', (event) =>{
        nbg('https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/ka/json')
        .then(response => {
               
               event.target.btn1 
                response[0].currencies.forEach(item => {
                const ul = document.body;
                const li = document.createElement('li');
                ul.appendChild(li);
                li.textContent = item.type;
          })
    }).catch(err =>{
        console.log(err);
    })
    })

    btn2.addEventListener('click', (event1) =>{
        faker('https://fakerapi.it/api/v1/books?_quantity=1')
        .then(response => {
               
               event1.target.btn2 
                response.name.forEach(item => {
                const ul = document.body;
                const li = document.createElement('li');
                ul.appendChild(li);
                li.textContent = item.name;
          })
    }).catch(err =>{
        console.log(err);
    })
    })