

function test1(url) {
    return new Promise ((resolve, reject) =>{
        if('https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/ka/json' === 200){
            resolve('server is on');
        }else{
            reject('error 404');
        }
    })
}


  

    async function testThis(){
    
        try{
            const result = await fetch('https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/ka/json')
            // console.log(result);
            return result.json();
        }catch(err){
            console.log(err);
        }
    }
    
    testThis();
    const value1 = testThis();
    console.log('value ', value1);





// testThis().then(item =>{
//     console.log('value', item) //დააბრუნა json-ის მნიშვნელობა
// })


function test2(url) {
    return new Promise ((resolve, reject) =>{
        if('https://fakerapi.it/api/v1/persons?_quantity=1&_gender=male&_birthday_start=2005-01-01'){
            resolve('server is on');
        }else{
            reject('error 404');
        }
    })
}




    async function testThat(){

        try{
            const result = await fetch('https://fakerapi.it/api/v1/persons?_quantity=1&_gender=male&_birthday_start=2005-01-01')
            console.log(result);
        }catch(err){
            console.log(err);
        }
    }
    
    testThat();

    const value2 = testThat();
    console.log('value ', value2);

